package com.example.magifinal.Pedidos

import androidx.lifecycle.ViewModel

class PedidosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}